#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>

// WiFi adatok
const char* ssid = "OnePlus 10R 5G";
const char* password = "w9avkz2e";

// DHT11 szenzor
#define DHTPIN 26  // DHT11 DATA pin (ESP32 GPIO 26)
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// GPIO pin a ventilátor PWM-vezérlésére
const int fanPin = 25;  // ESP32 GPIO 25
int dutyCycle = 0;      // Kezdeti ventilátor sebesség (0 = OFF, 255 = MAX sebesség)
bool manualOverride = false;
unsigned long manualOverrideTimer = 0;
const unsigned long manualOverrideTimeout = 10000;

// Webszerver
WebServer server(80);

void setup() {
  Serial.begin(115200);
  delay(10);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Csatlakozás WiFi-hez...");
  }

  Serial.println("Csatlakozva a WiFi-hez!");
  Serial.print("IP cím: ");
  Serial.println(WiFi.localIP());

  // PWM beállítása a ventilátorhoz
  analogWrite(fanPin, dutyCycle);  // Kezdeti PWM beállítás

  dht.begin();

  // Webszerver útvonalak
  server.on("/", HTTP_GET, handleRoot);
  server.on("/fan/start", HTTP_GET, turnFanOn);
  server.on("/fan/stop", HTTP_GET, turnFanOff);
  server.on("/fan/speed", HTTP_GET, setFanSpeed);
  server.on("/data", HTTP_GET, handleData);  // Új útvonal az automatikus frissítéshez

  server.begin();
}

void loop() {
  server.handleClient();

  if (manualOverride && (millis() - manualOverrideTimer > manualOverrideTimeout)) {
    manualOverride = false;
    Serial.println("Visszaállás automatikus módba.");
  }

  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (!manualOverride) {
    if (t >= 26 || h >= 70) {
      if (dutyCycle == 0) {
        dutyCycle = 255;
        analogWrite(fanPin, dutyCycle);
        Serial.println("Automatikus bekapcsolás magas hőmérséklet/páratartalom miatt!");
      }
    } else {
      if (dutyCycle != 0) {
        dutyCycle = 0;
        analogWrite(fanPin, dutyCycle);
        Serial.println("Automatikus kikapcsolás normál körülmények esetén!");
      }
    }
  }
}

void handleRoot() {
  String html = "<html><body><h1>Ventilator vezerles</h1>";
  html += "<p>Homerseklet: <span id='temperature'>...</span> C</p>";
  html += "<p>Paratartalom: <span id='humidity'>...</span> %</p>";
  html += "<p>Ventilator sebesseg: <span id='fanSpeed'>...</span></p>";
  html += "<p><a href='/fan/start'><button>Start Ventilator</button></a></p>";
  html += "<p><a href='/fan/stop'><button>Stop Ventilator</button></a></p>";

  html += "<p>Ventilator sebesseg beallitasa: <input type='range' min='0' max='255' value='" + String(dutyCycle) + "' id='fanSpeedControl' oninput='updateSpeed(this.value)'></p>";
  html += "<script>function updateSpeed(value) { fetch('/fan/speed?value=' + value); }</script>";

  // Automatikus frissítés JavaScript-el
  html += "<script>";
  html += "setInterval(() => { fetch('/data').then(response => response.json()).then(data => {";
  html += "document.getElementById('temperature').innerText = data.temperature;";
  html += "document.getElementById('humidity').innerText = data.humidity;";
  html += "document.getElementById('fanSpeed').innerText = data.fanSpeed;";
  html += "document.getElementById('fanSpeedControl').value = data.fanSpeed;";
  html += "}); }, 2000);";  // Frissítés 2 másodpercenként
  html += "</script>";

  html += "</body></html>";

  server.send(200, "text/html", html);
}

void turnFanOn() {
  manualOverride = true;
  manualOverrideTimer = millis();
  dutyCycle = 255;
  analogWrite(fanPin, dutyCycle);
  Serial.println("Manuális bekapcsolás!");
  server.sendHeader("Location", "/");
  server.send(303);
}

void turnFanOff() {
  manualOverride = true;
  manualOverrideTimer = millis();
  dutyCycle = 0;
  analogWrite(fanPin, dutyCycle);
  Serial.println("Manuális kikapcsolás!");
  server.sendHeader("Location", "/");
  server.send(303);
}

void setFanSpeed() {
  if (server.hasArg("value")) {
    dutyCycle = server.arg("value").toInt();
    analogWrite(fanPin, dutyCycle);
    manualOverride = true;
    manualOverrideTimer = millis();
    Serial.print("Ventilátor sebesség beállítva: ");
    Serial.println(dutyCycle);
  }
  server.send(204);  // No Content válasz, mivel nem kell új oldal
}

// Új JSON válasz a hőmérséklet, páratartalom és ventilátor sebességhez
void handleData() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  String json = "{\"temperature\":" + String(t) + ",\"humidity\":" + String(h) + ",\"fanSpeed\":" + String(dutyCycle) + "}";
  server.send(200, "application/json", json);
}
